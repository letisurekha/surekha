import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

 errorMessage:string;
 autherized:boolean;

//recieve authentication service and router in constructor
  constructor(public auth : AuthenticationService,public router : Router) {
  
  this.errorMessage="Invalid username and password";
  this.autherized=true;

   }
   checkLogin(uname:HTMLInputElement,pwd:HTMLInputElement){

    if(this.auth.authenticate(uname.value,pwd.value)){
      this.autherized=true;
      this.router.navigate(['/media']);
    }
    else{
      this.autherized=false;
    }
   }

  ngOnInit() {
  }

}

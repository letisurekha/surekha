export class Users{

id:Number;
userId:Number;
password:any;
email:any;
firstName:String;
LastName:String;
dob:any;
profilePic:any;

Users(id:Number,userId:Number,password:any,email:any,firstName:String,LastName:String,dob:any,profilePic:any){
    this.id=id;
    this.userId=userId;
    this.password=password;
    this.email=email;
    this.firstName=firstName;
    this.LastName=LastName;
    this.dob=dob;
    this.profilePic=profilePic;
}


}
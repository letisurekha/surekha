import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-groupt',
  templateUrl: './form-groupt.component.html',
  styleUrls: ['./form-groupt.component.css']
})
export class FormGrouptComponent implements OnInit {

  

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-media',
  templateUrl: './about-media.component.html',
  styleUrls: ['./about-media.component.css']
})
export class AboutMediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Injectable } from '@angular/core';
import { LogoutComponent } from '../acc/logout/logout.component';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  getAuthenticationToken: any;

  constructor() { }


//check username and password
  authenticate(username:string,password:string): boolean{

          if(username=="First" && password=="abc"){

            sessionStorage.setItem("user",username);
            return true;
          }
          else{

            return false;
          }
        
  }

  //check user either logged in or not
  isUserLoggedIn():boolean{

    let user=sessionStorage.getItem('user');
    if(user==null)
       return false;
    return true;   
  }
  //logout
  logout(){
    sessionStorage.removeItem('user');
  }

  getUserDetails():string{
    let user=sessionStorage.getItem('user');
    return user;
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultimediaMediaComponent } from './multimedia-media.component';

describe('MultimediaMediaComponent', () => {
  let component: MultimediaMediaComponent;
  let fixture: ComponentFixture<MultimediaMediaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultimediaMediaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultimediaMediaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

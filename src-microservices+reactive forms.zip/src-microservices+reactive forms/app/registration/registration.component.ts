import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  name:string;
  email:any;
  password:any;
  password1:any;
  errorMessage:string;
 autherized:boolean;
 myFormGroup : FormGroup;


  constructor(public router : Router,formBuilder: FormBuilder) { 

    this.errorMessage = "Invalid Credentials!!";
    this.autherized = true;
    this.myFormGroup=formBuilder.group({
     
      "name":new FormControl(""),
      "email":new FormControl(""),
      "password":new FormControl(""),
      "password1": new FormControl("")
        
     });


  }
  checkLogin(uname:HTMLInputElement,email:HTMLInputElement,pwd1:HTMLInputElement,pwd:HTMLInputElement){
    this.password=pwd.value;
    this.password1=pwd1.value;
    
    if(this.password==this.password1){


      this.autherized=true;
      this.router.navigate(['/login']);
    }
    else{
      this.autherized=false;
    }
    
  }

  login(){
    this.name= this.myFormGroup.controls['name'].value;
    this.email=this.myFormGroup.controls['email'].value;
    this.password= this.myFormGroup.controls['password'].value;
    this.password1=this.myFormGroup.controls['password1'].value;
    
     }
    

   ngOnInit() {
   }

}

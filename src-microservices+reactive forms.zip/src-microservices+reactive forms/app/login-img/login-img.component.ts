import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-img',
  templateUrl: './login-img.component.html',
  styleUrls: ['./login-img.component.css']
})
export class LoginImgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

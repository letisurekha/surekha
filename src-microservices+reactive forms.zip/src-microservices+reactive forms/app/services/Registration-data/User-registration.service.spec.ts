import { TestBed } from '@angular/core/testing';

import { UserDataService } from './User-registration.service';

describe('ProductDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserDataService = TestBed.get(UserDataService);
    expect(service).toBeTruthy();
  });
});

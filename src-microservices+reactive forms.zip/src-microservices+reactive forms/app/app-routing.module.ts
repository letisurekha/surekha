import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MediaComponent } from './head/media/media.component';
import { FollowersComponent } from './head/followers/followers.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { NewsfeedComponent } from './acc/newsfeed/newsfeed.component';
import { BlockedAccountComponent } from './acc/blocked-account/blocked-account.component';
import { SearchComponent } from './acc/search/search.component';
import { AccountComponent } from './account/account.component';
import { LogoutComponent } from './acc/logout/logout.component';
import { UpdateComponent } from './acc/update/update.component';
import { SingleMediaComponent } from './single-media/single-media.component';
import { MultimediaMediaComponent } from './multimedia-media/multimedia-media.component';
import { AboutMediaComponent } from './about-media/about-media.component';
import { AuthGuardService } from './services/auth-guard.service';


const routes: Routes = [
  { path:"", redirectTo : "login", pathMatch: "full"},
  { path:"login", component: LoginComponent},
  { path:"registration", component: RegistrationComponent},
  { path:"media", component: MediaComponent, canActivate : [AuthGuardService]},
  { path:"followers", component: FollowersComponent, canActivate : [AuthGuardService]},
  { path:"newsfeed", component: NewsfeedComponent, canActivate : [AuthGuardService]},
  { path:"blocked-account", component: BlockedAccountComponent, canActivate : [AuthGuardService]},
  { path:"search", component: SearchComponent, canActivate : [AuthGuardService]},
  { path:"update", component: UpdateComponent, canActivate : [AuthGuardService]},
  { path:"account", component: AccountComponent, canActivate : [AuthGuardService]},
  { path:"single-media", component: SingleMediaComponent, canActivate : [AuthGuardService]},
  { path:"multimedia-media", component: MultimediaMediaComponent, canActivate : [AuthGuardService]},
  { path:"about-media", component: AboutMediaComponent, canActivate : [AuthGuardService]},
  { path:"logout", component: LogoutComponent, canActivate : [AuthGuardService]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

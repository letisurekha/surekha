package com.cts.training.mediaservice.model;

import java.util.List;

import com.cts.training.mediaservice.entity.Media;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
public class MediaModel {

	private List <MediaData> medialist;
}

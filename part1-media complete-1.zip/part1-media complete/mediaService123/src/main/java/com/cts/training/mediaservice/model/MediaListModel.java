package com.cts.training.mediaservice.model;

import java.util.List;

public class MediaListModel {
	
	List<MediaModel> mediaList;

}

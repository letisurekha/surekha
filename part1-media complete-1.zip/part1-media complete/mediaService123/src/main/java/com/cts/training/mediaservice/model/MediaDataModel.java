package com.cts.training.mediaservice.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class MediaDataModel implements Serializable{
	
	private Integer userId;
	private String title;
	private String description;
	private String mimeType;
	private String tags;
	private String fileUrl;
	
	
	
	

}

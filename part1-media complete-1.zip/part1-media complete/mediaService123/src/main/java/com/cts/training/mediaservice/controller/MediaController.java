package com.cts.training.mediaservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.mediaservice.entity.Media;
import com.cts.training.mediaservice.exception.MediaErrorResponse;
import com.cts.training.mediaservice.exception.MediaNotFoundException;
import com.cts.training.mediaservice.model.MediaData;
import com.cts.training.mediaservice.model.MediaDataModel;
import com.cts.training.mediaservice.model.MediaListModel;
import com.cts.training.mediaservice.model.MediaModel;
import com.cts.training.mediaservice.model.MediaUploadModel;
import com.cts.training.mediaservice.repository.MediaRepository;
import com.cts.training.mediaservice.service.IMediaService;
import com.cts.training.mediaservice.service.StorageService;

@RestController
public class MediaController {

private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private IMediaService mediaService;
	
	@Autowired
	private StorageService storageService;

	@GetMapping("/mediabyid/{userId}")
	public ResponseEntity<MediaModel> getall(@PathVariable Integer userId){
		MediaModel medialist = new MediaModel();
		medialist.setMedialist(this.mediaService.getall(userId));
		ResponseEntity<MediaModel> result = new ResponseEntity<MediaModel>(medialist, HttpStatus.OK);
		return result;
		
	}
	
	
	@PostMapping(value = "/media", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public boolean save(MultipartFile file) {
		this.storageService.store(file);
		return true;
	}
	
	
	@PostMapping(value = "/mediadata")
	public boolean saveData(@RequestBody MediaUploadModel media) {
		MediaData mediamod = new MediaData();
		mediamod.setTitle(media.getTitle());
		mediamod.setDescription(media.getDescription());
		mediamod.setTags(media.getTags());
		mediamod.setUserId(media.getUserid());
		mediamod.setUrl(media.getUrl());
		mediamod.setType(media.getType());
		this.mediaService.save(mediamod);
		//this.storageService.store(file);
		return true;
	}
	
	@PutMapping("/media")
	public boolean update(@RequestBody MediaData user) {
		
		this.mediaService.updateuser(user);
		return true;
		
	}

	@ExceptionHandler  // ~catch
	public ResponseEntity<MediaErrorResponse> commentNotFoundHandler(MediaNotFoundException ex) {
		// create error object
		MediaErrorResponse error = new MediaErrorResponse(ex.getMessage(), 
															  HttpStatus.NOT_FOUND.value(), 
															  System.currentTimeMillis());
		ResponseEntity<MediaErrorResponse> response =
										new ResponseEntity<MediaErrorResponse>(error, HttpStatus.NOT_FOUND);
		
		return response;
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<MediaErrorResponse> commentOperationErrorHAndler(Exception ex) {
		// create error object
		MediaErrorResponse error = new MediaErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<MediaErrorResponse> response =
										new ResponseEntity<MediaErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}
	
	
	
}












package com.cts.training.Newsfeedservice.service;

import java.util.List;

import com.cts.training.Newsfeedservice.entity.Newsfeed;





public interface INewsfeedService {

	List<Newsfeed> findAllNewsfeeds();
	Newsfeed findNewsfeedById(Integer id);
	boolean addNewsfeed(Newsfeed Newsfeed);
	boolean updateNewsfeed(Newsfeed Newsfeed);
	boolean deleteNewsfeed(Integer id);
}

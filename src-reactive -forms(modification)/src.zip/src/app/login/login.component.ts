import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { Router } from '@angular/router';
import { User } from '../model/user';
import { UserserviceService } from '../services/userservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 

  errorMessage : string;
  name:string;
  password:string;
  myFormGroup:FormGroup;
  error:string;
  users:Array<User>
  constructor(private formBuilder : FormBuilder,public auth:AuthenticationService,public router:Router,private userService:UserserviceService) { 
    this.myFormGroup = this.formBuilder.group({
      "userName" : new FormControl(),
      "password" : new FormControl()
  }); 
  }
  register():void{
    this.router.navigate(['register']);
  }
  loginIn():void
  {
   
    this.name = this.myFormGroup.controls['userName'].value;
    this.password = this.myFormGroup.controls['password'].value;
      
    this.auth.authenticate(this.name, this.password).subscribe(
      successData=>
      {
        console.log("SUCCESS...");
        console.log(successData);
        this.router.navigate(['/mymedia']);
      },
      failureData => 
      {
        console.log("FAILED!!!");
       this.errorMessage="Invalid credentials"
      }
    
      );

  }  
      

   ngOnInit() {
  }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MediaComponent } from './head/media/media.component';
import { FollowersComponent } from './head/followers/followers.component';
import { AccountComponent } from './account/account.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { NewsfeedComponent } from './acc/newsfeed/newsfeed.component';
import { BlockedAccountComponent } from './acc/blocked-account/blocked-account.component';
import { SearchComponent } from './acc/search/search.component';
import { LogoutComponent } from './acc/logout/logout.component';
import { UpdateComponent } from './acc/update/update.component';
import { SingleMediaComponent } from './single-media/single-media.component';
import { MultimediaMediaComponent } from './multimedia-media/multimedia-media.component';
import { AboutMediaComponent } from './about-media/about-media.component';
import { HeadComponent } from './head/head.component';
import { LoginImgComponent } from './login-img/login-img.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    MediaComponent,
    FollowersComponent,
    AccountComponent,
    LoginComponent,
    RegistrationComponent,
    NewsfeedComponent,
    BlockedAccountComponent,
    SearchComponent,
    LogoutComponent,
    UpdateComponent,
    SingleMediaComponent,
    MultimediaMediaComponent,
    AboutMediaComponent,
    HeadComponent,
    LoginImgComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

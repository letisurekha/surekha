export class Uname
{
    username:string;
}
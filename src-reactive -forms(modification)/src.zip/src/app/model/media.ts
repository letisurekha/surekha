export class Media
{
    id:number;
    title:string;
    description:string;
    tags:string;
}
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserserviceService } from 'src/app/services/userservice.service';
import { Uname } from 'src/app/model/uname';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  
      usernames:Array<Uname>;
      myFormGroup: FormGroup;
      uname:string;
      errorMessage:string;
      buser:boolean=false
      constructor(formBuilder: FormBuilder, public router: Router,
        public auth: AuthenticationService,
        private userService: UserserviceService
      ) {
        this.myFormGroup = formBuilder.group({
          "id": new FormControl(""),
          "username": new FormControl("",Validators.required),
          "password": new FormControl("",Validators.required),
          "email": new FormControl("",[Validators.required, Validators.email]),
          "firstName": new FormControl("",Validators.required),
          "lastName": new FormControl("",Validators.required),
          "dob": new FormControl("",Validators.required),
          "profilePic": new FormControl("",Validators.required)
        });
      }
      register(): void {
        
          this.userService.addUser(this.myFormGroup.value).subscribe(data=>{
            alert("Registered successfully")
            this.login();
          })
      }
      login(): void {
        this.router.navigate(['login']);
      }
      getAllUserNames():void
      {
        this.userService.getUserNames().subscribe(data => {
          this.usernames = data;
          for( let sername of this.usernames)
          {
          if(sername.username==this.myFormGroup.get('username').value)
          {
            this.errorMessage="username Taken"
            this.buser=true;
              break;
          }
          else
          this.errorMessage="successs"
          }})
        }    


  ngOnInit() {
  }

}

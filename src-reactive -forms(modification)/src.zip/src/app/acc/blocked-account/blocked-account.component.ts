import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blocked-account',
  templateUrl: './blocked-account.component.html',
  styleUrls: ['./blocked-account.component.css']
})
export class BlockedAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

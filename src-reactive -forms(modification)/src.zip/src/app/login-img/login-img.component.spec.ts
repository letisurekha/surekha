import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginImgComponent } from './login-img.component';

describe('LoginImgComponent', () => {
  let component: LoginImgComponent;
  let fixture: ComponentFixture<LoginImgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginImgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginImgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

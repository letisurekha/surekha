import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multimedia-media',
  templateUrl: './multimedia-media.component.html',
  styleUrls: ['./multimedia-media.component.css']
})
export class MultimediaMediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

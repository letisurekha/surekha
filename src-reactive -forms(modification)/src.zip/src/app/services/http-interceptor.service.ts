import { Injectable } from '@angular/core';
import { AuthenticationService } from './authentication.service';
import { HttpRequest, HttpHandler } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpInterceptorService {


  constructor(public auth : AuthenticationService) { }

  intercept(request: HttpRequest<any>, next: HttpHandler){

    if(this.auth.getAuthenticationToken()){
      
      let authenticationToken = this.auth.getAuthenticationToken();    
      request = request.clone({
        setHeaders : {
          Authorization : authenticationToken
        }
      });
    }

    return next.handle(request);
  }
}

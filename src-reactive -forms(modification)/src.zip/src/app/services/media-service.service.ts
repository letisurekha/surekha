import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Media } from '../model/media';

@Injectable({
  providedIn: 'root'
})
export class MediaServiceService {

  URL="http://localhost:3000/media/"
  constructor(public http:HttpClient) { }
  addSingleMedia(singlemedia:Media):Observable<Media>
  {
    return this.http.post<Media>(this.URL,Media)
  }
  getAllSingleMedia():Observable<Media[]>
  {
    return this.http.get<Media[]>(this.URL);
  }
  getSingleMediaById(id:number):Observable<Media>
  {
    return this.http.get<Media>(this.URL+id);
  }
}

import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import {map} from 'rxjs/operators';


const VALIDATION_URL = "http://localhost:8765/user-service/login";
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {


  constructor(public http : HttpClient) { }

 

  authenticate(userid : string, password : string){
    
    let authenticationToken = "Basic " + window.btoa(userid + ":" + password);
    console.log(authenticationToken);

    let headers = new HttpHeaders({
      Authorization : authenticationToken
    });

   
    return this.http.get(VALIDATION_URL, {headers}).pipe(
     
      map(successData=>{
        sessionStorage.setItem("user", userid);
     
        sessionStorage.setItem("token", authenticationToken);
        return successData;
      }),
     
      map(failureData=>{
        
        return failureData;
      })
    );
  }

  
  getAuthenticationToken(){
    if(this.isUserLoggedIn())
      return sessionStorage.getItem("token");
    return null; 
  }


  isUserLoggedIn(): boolean{
  
    let user = sessionStorage.getItem('user');
    if(user == null)
      return false;
    return true;  
  }

  
  logout(){
    
    sessionStorage.removeItem('user');
   
  }

 
  getUserDetails():string{
    let user = sessionStorage.getItem('user');
    return user;
  }


}

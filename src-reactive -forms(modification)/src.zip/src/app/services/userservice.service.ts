import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user';
import { Uname } from '../model/uname';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  
  URL="http://localhost:8765/user-service/register"
  USERNAME_URL="http://localhost:8765/user-service/usernames"
  constructor(public http : HttpClient) { }
  addUser(user:User):  Observable<User>
  {
    return this.http.post<User>(this.URL,user);
  }
  getAllUsers():Observable<User[]>{
    return this.http.get<User[]>(this.URL);
  }
  getUserNames():Observable<Uname[]>
  {
    return this.http.get<Uname[]>(this.USERNAME_URL);
  }
}

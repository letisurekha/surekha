package com.cts.training.casestudy1.user.exception;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserErrorResponse {

	private String message;
	private Integer errorCode;
	private Long timeStamp;
	
	
	
}

package com.cts.training.casestudy1.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cts.training.casestudy1.user.entity.User;
import com.cts.training.casestudy1.user.repository.user.UserRepository;


@Service
public class UserServiceImp implements IUserService {

	@Autowired
	//@Qualifier("productDaoHibernateImpl")
	// @Qualifier("productDaoJdbcTemplateImpl")
	private UserRepository userRepository;
	
	@Override
	public List<User> findAllUsers() {
		
		return this.userRepository.findAll();
		
	}

	@Override
	public User findUserById(Integer id) {
		

		//return this.userRepository.findById(id);
				//Optional<User> record =  this.userRepository.findById(id);
		
		     Optional<User> record =  this.userRepository.findById(id);
				// reduces the chance of NullException
				
				// can check if object is there
				User user = new User();
				if(record.isPresent())
					user= record.get();
				return user;
		
	}

	@Override
	public boolean addUser(User user) {
		
		this.userRepository.save(user);
		return true;
	}

	@Override
	public boolean updateUser(User user) {
		
		this.userRepository.save(user);
		return true;
	}

	@Override
	public boolean deleteUser(Integer id) {
		

		this.userRepository.deleteById(id);
		return true;
	}

}

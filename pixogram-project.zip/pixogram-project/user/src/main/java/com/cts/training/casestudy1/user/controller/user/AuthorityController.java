package com.cts.training.casestudy1.user.controller.user;

public class AuthorityController {

}

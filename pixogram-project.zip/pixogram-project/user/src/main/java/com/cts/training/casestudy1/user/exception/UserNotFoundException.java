package com.cts.training.casestudy1.user.exception;

public class UserNotFoundException extends RuntimeException{
	public UserNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}

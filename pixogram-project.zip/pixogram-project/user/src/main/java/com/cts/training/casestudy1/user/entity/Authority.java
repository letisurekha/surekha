package com.cts.training.casestudy1.user.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Table(name = "authorities")
public class Authority {
	
    @Id
	@Column(name="userName",length=150) 
	private String userName;
	
	@Column(name="authority_Role",length=150) 
	private String authority_Role;

}

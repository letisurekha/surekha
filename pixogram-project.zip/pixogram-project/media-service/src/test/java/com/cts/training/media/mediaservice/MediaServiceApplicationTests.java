package com.cts.training.media.mediaservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

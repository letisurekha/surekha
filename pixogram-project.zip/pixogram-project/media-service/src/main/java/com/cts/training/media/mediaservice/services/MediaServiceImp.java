package com.cts.training.media.mediaservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import com.cts.training.media.mediaservice.entity.Media;
import com.cts.training.media.mediaservice.repository.MediaRepository;

@Service
public class MediaServiceImp implements IMediaService {
	
	@Autowired
	//@Qualifier("productDaoHibernateImpl")
	// @Qualifier("productDaoJdbcTemplateImpl")
	private MediaRepository mediaRepository;

	@Override
	public List<Media> findAllMedia() {
		
		return this.mediaRepository.findAll();
	}

	@Override
	public Media findMediaById(Integer id) {
		
		//return this.userRepository.findById(id);
				Optional<Media> record =  this.mediaRepository.findById(id);
				// reduces the chance of NullException
				
				// can check if object is there
				Media media = new Media();
				if(record.isPresent())
					media= record.get();
				return media;
				
		
	}

	@Override
	public boolean addMedia(Media media) {
		
		this.mediaRepository.save(media);
		return true;
	}

	@Override
	public boolean updateMedia(Media media) {
		this.mediaRepository.save(media);
		return true;
	}

	@Override
	public boolean deletemedia(Integer id) {
		
		
		this.mediaRepository.deleteById(id);
		return true;
	}
	
	
	
}

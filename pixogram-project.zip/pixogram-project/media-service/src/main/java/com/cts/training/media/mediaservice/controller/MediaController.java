package com.cts.training.media.mediaservice.controller;

public class MediaController {

}

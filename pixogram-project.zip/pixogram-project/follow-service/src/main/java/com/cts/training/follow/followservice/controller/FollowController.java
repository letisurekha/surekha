package com.cts.training.follow.followservice.controller;



public class FollowController {
	
	
	

}

package com.cts.training.catalog.catalog.model;

public class catalogData {
	
	

}

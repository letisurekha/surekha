package com.cts.training.catalog.catalog.model;

import java.time.LocalDateTime;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;





@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class UserInfomation {
	
	

	
	private Integer id;
	
	
	private String firstName;
	

	private String lastName;
	

	private String userName;
	

	private String password;
	

    private String dob;
	

	private String pic;
	
	
	private LocalDateTime createdOn;
	

	private LocalDateTime updatedOn;
	

	private boolean enabled;
	
	
	
	
	
	
	
	
}	
	
	
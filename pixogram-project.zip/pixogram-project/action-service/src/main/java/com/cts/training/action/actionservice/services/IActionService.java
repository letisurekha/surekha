package com.cts.training.action.actionservice.services;
import java.util.List;

import com.cts.training.action.actionservice.entity.Action;

public interface IActionService {
	
	List<Action> findAllMedia();
	Action findActionById(Integer id);
	boolean addAction(Action action);
	boolean updateAction(Action media);
	boolean deleteAction(Integer id);

}

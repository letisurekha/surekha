package com.cts.training.action.actionservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cts.training.action.actionservice.entity.Action;
import com.cts.training.action.actionservice.repository.ActionRepository;

@Service
public class ActionServiceImp implements IActionService {

	
	@Autowired
	//@Qualifier("productDaoHibernateImpl")
	// @Qualifier("productDaoJdbcTemplateImpl")
	private ActionRepository actionRepository;
	
	
	@Override
	public List<Action> findAllMedia() {
		return this.actionRepository.findAll();
	}

	@Override
	public Action findActionById(Integer id) {
		//return this.userRepository.findById(id);
		Optional<Action> record =  this.actionRepository.findById(id);
		// reduces the chance of NullException
		
		// can check if object is there
		Action action = new Action();
		if(record.isPresent())
			action= record.get();
		return action;
	}

	@Override
	public boolean addAction(Action action) {
		
		this.actionRepository.save(action);
		return true;
		
	}

	@Override
	public boolean updateAction(Action action) {
		
		this.actionRepository.save(action);
		return true;
	}

	@Override
	public boolean deleteAction(Integer id) {
		this.actionRepository.deleteById(id);
		return true;
	}
	
	
	
}

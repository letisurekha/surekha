package com.cts.training.action.actionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

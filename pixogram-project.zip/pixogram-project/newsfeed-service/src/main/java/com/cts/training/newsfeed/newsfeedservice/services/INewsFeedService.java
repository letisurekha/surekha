package com.cts.training.newsfeed.newsfeedservice.services;
import java.util.List;

import com.cts.training.newsfeed.newsfeedservice.entity.NewsFeed;


public interface INewsFeedService {
	
	List<NewsFeed> findAllNewsFeed();
	NewsFeed findNewsFeedById(Integer id);
	boolean addNewsFeed(NewsFeed newsfeed);
	boolean updateNewsFeed(NewsFeed newsfeed);
	boolean deleteNewsFeed(Integer id);

}

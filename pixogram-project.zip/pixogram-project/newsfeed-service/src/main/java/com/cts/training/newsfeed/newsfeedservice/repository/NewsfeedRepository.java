package com.cts.training.newsfeed.newsfeedservice.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cts.training.newsfeed.newsfeedservice.entity.NewsFeed;


@Repository
public interface NewsfeedRepository  extends JpaRepository <NewsFeed, Integer>{

}

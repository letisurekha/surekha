package com.cts.training.newsfeed.newsfeedservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.newsfeed.newsfeedservice.entity.NewsFeed;
import com.cts.training.newsfeed.newsfeedservice.exceptions.NewsFeedErrorResponse;
import com.cts.training.newsfeed.newsfeedservice.exceptions.NewsFeedNotFoundException;
import com.cts.training.newsfeed.newsfeedservice.services.INewsFeedService;



@RestController
@RequestMapping("/api")
//@CrossOrigin("http://localhost:4200")
public class NewsFeedControllers {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	// dependency
	@Autowired
	private INewsFeedService newsfeedService;
	
	// @RequestMapping(value =  "/products", method = {RequestMethod.GET, RequestMethod.PUT} )
	@GetMapping("/newsfeeds") // GET HTTP VERB
	public ResponseEntity<List<NewsFeed>> exposeAll() {
		
		List<NewsFeed> newsfeeds = this.newsfeedService.findAllNewsFeed();
		// if(newsfeeds.size() == 0)
		if(newsfeeds == null)
			throw new NewsFeedNotFoundException("Not able to fetch records!!!");
		ResponseEntity<List<NewsFeed>> response = 
								new ResponseEntity<List<NewsFeed>>(newsfeeds, HttpStatus.OK);
		
		
		return response;
	}
	
	// {<data variable>}
	@GetMapping("/newsfeeds/{newwsfeedId}") // GET HTTP VERB
	public ResponseEntity<NewsFeed> getById(@PathVariable Integer newsfeedId) {
		
		NewsFeed newsfeed = this.newsfeedService.findNewsFeedById(newsfeedId);
		if(newsfeed == null)
			throw new NewsFeedNotFoundException("Product with id-" + newsfeedId + " not Found");
		
		ResponseEntity<NewsFeed> response = 
				new ResponseEntity<NewsFeed>(newsfeed, HttpStatus.OK);

		return response;
	}
	
	// @RequestMapping(value =  "/products", method = RequestMethod.POST)
	@PostMapping("/users") // POST HTTP VERB
	public ResponseEntity<NewsFeed> save(@RequestBody NewsFeed newsfeed) {
		if(!this.newsfeedService.addNewsFeed(newsfeed))
			throw new RuntimeException("Could not add new record!!!");
		ResponseEntity<NewsFeed> response = 
				new ResponseEntity<NewsFeed>(newsfeed, HttpStatus.OK);

		return response;
	}
	
	@PutMapping("/newfeeds")
	public ResponseEntity<NewsFeed> saveUpdate(@RequestBody NewsFeed newsfeed) {
		if(!this.newsfeedService.updateNewsFeed(newsfeed))
			throw new RuntimeException("Could not update record!!!");
		ResponseEntity<NewsFeed> response = 
				new ResponseEntity<NewsFeed>(newsfeed, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/newsfeeds/{newsfeedId}")
	public ResponseEntity<NewsFeed> delete(@PathVariable Integer newsfeedId) {
		
		NewsFeed newsfeed = this.newsfeedService.findNewsFeedById(newsfeedId);
		if(newsfeed == null)
			throw new NewsFeedNotFoundException("newsfeed with id-" + newsfeedId + " not Found");
		
		// send productId to DAO via SERVICE
		this.newsfeedService.deleteNewsFeed(newsfeedId);
		
		ResponseEntity<NewsFeed> response = 
				new ResponseEntity<NewsFeed>(newsfeed, HttpStatus.OK);

		return response;
	}
	
	
	// for exception handling
	@ExceptionHandler  // ~catch
	public ResponseEntity<NewsFeedErrorResponse> newsfeedNotFoundHandler(NewsFeedNotFoundException ex) {
		// create error object
		NewsFeedErrorResponse error = new NewsFeedErrorResponse(ex.getMessage(), 
															  HttpStatus.NOT_FOUND.value(), 
															  System.currentTimeMillis());
		ResponseEntity<NewsFeedErrorResponse> response =
										new ResponseEntity<NewsFeedErrorResponse>(error, HttpStatus.NOT_FOUND);
		
		return response;
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<NewsFeedErrorResponse> newsfeedOperationErrorHAndler(Exception ex) {
		// create error object
		NewsFeedErrorResponse error = new NewsFeedErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<NewsFeedErrorResponse> response =
										new ResponseEntity<NewsFeedErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}
	
	
	
	/************ REST endpoints ************/
	// /api/product [GET]
	// /api/product/id [GET]
	// /api/product [POST]
	// /api/product [PUT]
	// /api/product/id [DELETE]
	
	
	
	
}

package com.cts.training.newsfeed.newsfeedservice.controller;

public class NewsFeedController {

}

package com.cts.training.newsfeed.newsfeedservice.exceptions;

public class NewsFeedNotFoundException extends RuntimeException{
	public NewsFeedNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}

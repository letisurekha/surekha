package com.cts.training.newsfeed.newsfeedservice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cts.training.newsfeed.newsfeedservice.entity.NewsFeed;
import com.cts.training.newsfeed.newsfeedservice.repository.NewsfeedRepository;

@Service
public class NewsFeedServiceImp implements INewsFeedService {

	@Autowired
	//@Qualifier("productDaoHibernateImpl")
	// @Qualifier("productDaoJdbcTemplateImpl")
	private NewsfeedRepository newsfeedRepository;
	
	
	@Override
	public List<NewsFeed> findAllNewsFeed() {
		
		return this.newsfeedRepository.findAll();
		
	}

	@Override
	public NewsFeed findNewsFeedById(Integer id) {
		
		//return this.userRepository.findById(id);
				Optional<NewsFeed> record =  this.newsfeedRepository.findById(id);
				// reduces the chance of NullException
				
				// can check if object is there
				NewsFeed newsfeed = new NewsFeed();
				if(record.isPresent())
					newsfeed= record.get();
				return newsfeed;
	}

	@Override
	public boolean addNewsFeed(NewsFeed newsfeed) {
		
		this.newsfeedRepository.save(newsfeed);
		return true;
		
	}

	@Override
	public boolean updateNewsFeed(NewsFeed newsfeed) {
		
		this.newsfeedRepository.save(newsfeed);
		return true;
	}

	@Override
	public boolean deleteNewsFeed(Integer id) {
		
		this.newsfeedRepository.deleteById(id);
		return true;
	}

	
}

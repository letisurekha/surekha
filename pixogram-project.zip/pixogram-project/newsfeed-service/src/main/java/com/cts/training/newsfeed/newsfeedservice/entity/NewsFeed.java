package com.cts.training.newsfeed.newsfeedservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Table(name = "newsfeed")
public class NewsFeed {
	
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer userId;
	
	private Integer mediaId;
	
	@Column(name="feed")
	private String feed;
	
	@CreationTimestamp
	@Column
	private LocalDateTime CreatedOn;
	
	
	

}

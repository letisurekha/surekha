package com.cts.training.blocking.blockingservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.blocking.blockingservice.entity.Blocking;

@Repository
public interface BlockedRepository  extends JpaRepository <Blocking, Integer>{

}

package com.cts.training.blocking.blockingservice.controller;

public class BlockingController {

}

package com.cts.training.blocking.blockingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlockingServiceApplication.class, args);
	}

}

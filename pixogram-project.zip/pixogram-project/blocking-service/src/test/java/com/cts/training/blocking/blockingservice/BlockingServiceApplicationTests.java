package com.cts.training.blocking.blockingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlockingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.cts.training.comments.commentsservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.comments.commentsservice.entity.Comments;

@Repository
public interface CommentsRepository extends JpaRepository <Comments, Integer> {

}

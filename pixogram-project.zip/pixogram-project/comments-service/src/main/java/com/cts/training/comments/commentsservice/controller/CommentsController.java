package com.cts.training.comments.commentsservice.controller;

public interface CommentsController {
	
	
	
	
	
	
	

}

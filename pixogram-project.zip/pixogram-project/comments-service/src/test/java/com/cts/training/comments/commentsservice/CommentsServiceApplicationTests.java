package com.cts.training.comments.commentsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommentsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
